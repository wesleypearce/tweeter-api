module.exports.consumerKey = "bQl7EvgtZrPGI5eKzP4dlkn9G";
module.exports.twitterBearerToken =
  "AAAAAAAAAAAAAAAAAAAAADl%2FGgEAAAAAi%2BVrZLq6QYq%2Bm0aK3qb3o6vjek0%3DMvlYYkB9B7XFiEmwXoZbMw5GleScNPBpvKkOO0zupB8GPrdK57";
module.exports.consumerSecret =
  "O3Oikfe7h8YhyuHXVj1pq8oBgYLnhPTigLbEsa24Gav0diIMf6";
